Kai Tan <tank5@uw.edu>​
TheftDetector - the Timer T = 8 seconds.It may take 30 seconds to connect to Bluetooth for the first time.
